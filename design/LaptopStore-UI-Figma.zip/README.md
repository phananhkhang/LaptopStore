# LaptopStore — bộ giao diện trắng / cam

Bộ thiết kế desktop gồm **57 màn hình và trạng thái**, **24 component được đăng ký**, **49 biến màu/khoảng cách/bo góc**, **742 liên kết điều hướng**. Font: Be Vietnam Pro. Assets laptop, kiện hàng và icons được vẽ bằng SVG nguyên bản.

## Xem thiết kế ngay

Mở [preview.html](preview.html) bằng trình duyệt. Chọn màn hình ở thanh trên cùng hoặc bấm các nút trong giao diện để đi theo prototype. File HTML chứa sẵn toàn bộ dữ liệu thiết kế; Google Fonts được dùng nếu trình duyệt có kết nối mạng.

Ba điểm bắt đầu là Cửa hàng, Không gian Staff và Không gian Admin. Đây là prototype dữ liệu mẫu; các nút không gửi đơn hàng, thanh toán hoặc sửa tài khoản thật.

## Đưa toàn bộ vào Figma

Gói [figma-plugin/manifest.json](figma-plugin/manifest.json) chạy trong **Figma desktop**:

1. Mở file Figma của dự án hoặc một file Design trống.
2. Trong menu Figma, chọn **Plugins → Development → Import plugin from manifest…** và chọn `design/figma-plugin/manifest.json`.
3. Chạy **LaptopStore · Full UI & Prototype**, rồi bấm **Dựng toàn bộ giao diện & prototype**.
4. Plugin tạo một page mới gồm toàn bộ màn hình, components, SVG vector, variables và prototype. Các page có sẵn được giữ lại. Các biến và text styles LaptopStore đã có được tái sử dụng.
5. Sau khi chạy xong, plugin xuất ba ảnh preview của User / Staff / Admin và báo số màn, font và liên kết. Bấm Present tại frame `00 · Bắt đầu prototype`.

Mỗi lần bấm dựng sẽ tạo một page mới. Plugin không gọi mạng. Không cần API key, server backend hoặc database để tạo thiết kế.

## Đối chiếu đặc tả và source

[SCREEN-INVENTORY.md](SCREEN-INVENTORY.md) ánh xạ các màn tới ERD, đặc tả, route và endpoint hiện có. Các phần backend có nhưng frontend thiếu, cùng các phần mới có trong đặc tả, được phân biệt tại đây. Không sửa code ứng dụng.

Mẫu mua hàng chính dùng ASUS ROG Strix G15, SKU ROG-G15-01, giá 25.000.000₫, coupon LAPTOP500 giảm 500.000₫, tổng 24.500.000₫. Đơn hàng vận hành và giao dịch khác dùng dữ liệu minh họa riêng. Trạng thái đơn theo enum hiện tại: PENDING, CONFIRMED, PROCESSING, SHIPPING, DELIVERED, CANCELLED, RETURNED.

## Hiện trạng bàn giao

- File Figma đã tạo: https://www.figma.com/design/mTuhPG74JMEAuqKNrL8KSn . **File này mới có foundations, components và 14 khung ban đầu; chưa chứa bộ 57 màn hoàn chỉnh.**
- Figma MCP báo hết lượt trên Starter trước bước import assets và dựng nội dung.
- Máy hiện không có cửa sổ Figma desktop. Điều khiển trình duyệt dừng vì công cụ không xác minh được URL Windows.
- Vì vậy, bộ hoàn chỉnh được bàn giao dưới dạng preview tương tác và plugin import. **Plugin chưa được chạy/kiểm chứng trong Figma thật.**

## Kiểm tra đã thực hiện

- Parse toàn bộ JavaScript, SVG XML và JSON.
- Chạy đủ 7 giai đoạn trên bộ mô phỏng Plugin API cục bộ: 57 màn được điền đầy đủ, không màn trống, không shimmer còn sót, không asset tràn.
- Kiểm tra bố cục mô phỏng: không phát hiện nội dung tràn; hai trang dài được tăng chiều cao để cuộn.
- 742 liên kết có đích hợp lệ, không còn control được đánh dấu tương tác mà chưa ánh xạ.

Kết quả mô phỏng không thay cho render/kiểm tra Figma thật. Số đo chữ sử dụng ước lượng; cần xem ba ảnh preview plugin xuất sau khi chạy để xác nhận font và bố cục thực tế.

## Tạo lại artifacts

Chạy từ thư mục gốc LaptopStore:

```powershell
node design/figma-build/smoke-mock.cjs --write
node design/figma-build/render-preview.cjs
node design/figma-build/package-design.cjs
```

Các script authoring riêng nằm trong [figma-build](figma-build). Assets web SVG có thể lấy trực tiếp trong [figma-assets](figma-assets).
